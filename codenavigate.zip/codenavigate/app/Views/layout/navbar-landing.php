<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

        <a href="#" class="logo d-flex align-items-center me-auto">
            <!-- Uncomment the line below if you also wish to use an image logo -->
            <img src="/img/logo1.png" alt="">
            <h2 class="sitename">Code Navigate</h2>
        </a>
        <div class="nav">
            <nav id="navmenu" class="navmenu">
                <ul>
                    <!-- <li><a href="/home" class="">Home</a></li>
                    <li><a href="/class">Class</a></li>
                    <li><a href="/bootcamp">Bootcamp</a></li>
                    <li><a href="/history">History</a></li>
                    <li><a href="#">Profile</a></li> -->
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>
        </div>
        <a class="btn-getstarted" href="/login">Login</a>
    </div>
</header>