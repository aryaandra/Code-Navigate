<nav class="sidebar">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="/img/logo1.png" alt="logo">
                </span>

                <div class="text header-text">
                    <span class="name">Code Navigate</span><br>
                    <span class="profession">Dashboard Admin</span>
                </div>
            </div>
        </header>

        <div class="menu-bar">
            <div class="menu">
                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="/admin/data_admin">
                            <i class='bx bxs-user icon'></i>
                            <span class="text nav-text">Data Admin</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="/admin/data_user">
                            <i class='bx bxs-user-account icon'></i>
                            <span class="text nav-text">Data User</span>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="bottom-content">
                <li class="nav-link">
                    <a href="/logout">
                        <i class='bx bx-log-out icon'></i>
                        <span class="text nav-text">Log Out</span>
                    </a>
                </li>
            </div>
        </div>
    </nav>