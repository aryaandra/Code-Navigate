<footer id="footer" class="footer">
    <div class="container footer-top">
        <div class="row gy-4">
            <div class="col-lg-4 col-md-6 footer-about">
                <a href="/home" class="d-flex align-items-center">
                    <span class="sitename">Code Navigate</span>
                </a>
                <div class="footer-contact pt-3">
                    <p>Jl. Widas Blok N No. 10</p>
                    <p>Malang, Jawa Timur 60123</p>
                    <p class="mt-3"><strong>Phone:</strong> <span>+62 8224 2642 870</span></p>
                    <p><strong>Email:</strong> <span>aryaandramirza@gmail.com</span></p>
                </div>
            </div>

            <div class="col-lg-2 col-md-3 footer-links">
                <h4>Useful Links</h4>
                <ul>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">Home</a></li>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">About us</a></li>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">Services</a></li>
                    <!-- <li><i class='bx bx-chevron-right'></i> <a href="#">Terms of service</a></li> -->
                </ul>
            </div>

            <!-- <div class="col-lg-2 col-md-3 footer-links">
                <h4>Our Services</h4>
                <ul>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">Web Design</a></li>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">Web Development</a></li>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">Product Management</a></li>
                    <li><i class='bx bx-chevron-right'></i> <a href="#">Marketing</a></li>
                </ul>
            </div> -->

            <div class="col-lg-4 col-md-12">
                <h4>Follow Us</h4>
                <div class="social-links d-flex">
                    <a href="https://api.whatsapp.com/send?phone=62895397113280" target="_blank"><i class='bx bxl-whatsapp'></i></a>
                    <a href="https://www.instagram.com/code.navigate/" target="_blank"><i class='bx bxl-instagram'></i></a>
                    <a href="https://www.linkedin.com/in/arya-andra-9545222a5/" target="_blank"><i class='bx bxl-linkedin'></i></a>
                </div>
            </div>

        </div>
    </div>

    <div class="container copyright text-center mt-4">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">Code Navigate</strong> <span>All Rights
                Reserved</span></p>
        <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you've purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->

        </div>
    </div>

</footer>