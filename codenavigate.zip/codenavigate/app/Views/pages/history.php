<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<main>
    <section style="background-color: #37517e;">
    </section>

    <section id="testimonials" class="testimonials section">

        <!-- Section Title -->
        <div class="container section-title" data-aos="fade-up">
            <h2>History</h2>
        </div><!-- End Section Title -->
        <div class="swiper-wrapper">

            <div class="swiper-slide">
                <div class="testimonial-item">
                    <h3>Saul Goodman</h3>
                    <p>
                        arghqaerghqeaurhgqaregnqaerg
                    </p>
                </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
                <div class="testimonial-item">
                    <h3>Sara Wilsson</h3>
                    <p>
                        fgioaegfuqergfh
                    </p>
                </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
                <div class="testimonial-item">
                    <h3>Jena Karlis</h3>
                    <p>
                        faerghuqearhgurf
                    </p>
                </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
                <div class="testimonial-item">
                    <h3>Matt Brandon</h3>
                    <p>
                        ioejhyitjpeih
                    </p>
                </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
                <div class="testimonial-item">
                    <h3>John Larson</h3>
                    <p>
                        jughwtruehguqhrtliq
                    </p>
                </div>
            </div><!-- End testimonial item -->

        </div>
        <div class="swiper-pagination"></div>

        </div>

    </section>
</main>
<?= $this->endSection(''); ?>